﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("10.0.17134.556")]
[assembly: AssemblyTitle("Хост-процесс для служб Windows")]
[assembly: AssemblyDescription("Хост-процесс для служб Windows")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Windows")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("736b3a7c-a758-4489-b1a4-22d8ed01f4c2")]
[assembly: AssemblyFileVersion("10.0.17134.556")]
