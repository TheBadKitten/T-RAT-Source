﻿using System;

namespace TelegramBot
{
	// Token: 0x020000DA RID: 218
	internal class FirstModel
	{
		// Token: 0x1700000B RID: 11
		// (get) Token: 0x060002AF RID: 687 RVA: 0x00002F89 File Offset: 0x00001189
		// (set) Token: 0x060002B0 RID: 688 RVA: 0x00002F91 File Offset: 0x00001191
		public string Command { get; set; }

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x060002B1 RID: 689 RVA: 0x00002F9A File Offset: 0x0000119A
		// (set) Token: 0x060002B2 RID: 690 RVA: 0x00002FA2 File Offset: 0x000011A2
		public string[] Args { get; set; }
	}
}
