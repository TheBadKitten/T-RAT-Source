﻿using System;

namespace TelegramBot
{
	// Token: 0x020000DB RID: 219
	internal class SecondModel
	{
		// Token: 0x1700000D RID: 13
		// (get) Token: 0x060002B4 RID: 692 RVA: 0x00002FAB File Offset: 0x000011AB
		// (set) Token: 0x060002B5 RID: 693 RVA: 0x00002FB3 File Offset: 0x000011B3
		public string Command { get; set; }

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x060002B6 RID: 694 RVA: 0x00002FBC File Offset: 0x000011BC
		// (set) Token: 0x060002B7 RID: 695 RVA: 0x00002FC4 File Offset: 0x000011C4
		public string Arg { get; set; }
	}
}
