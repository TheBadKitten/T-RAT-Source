﻿using System;

namespace TelegramBot
{
	// Token: 0x02000010 RID: 16
	internal class Purse
	{
		// Token: 0x04000018 RID: 24
		public static string wmr;

		// Token: 0x04000019 RID: 25
		public static string wmz;

		// Token: 0x0400001A RID: 26
		public static string wme;

		// Token: 0x0400001B RID: 27
		public static string wmx;

		// Token: 0x0400001C RID: 28
		public static string btc;

		// Token: 0x0400001D RID: 29
		public static string ripple;

		// Token: 0x0400001E RID: 30
		public static string cc;

		// Token: 0x0400001F RID: 31
		public static string btcg;

		// Token: 0x04000020 RID: 32
		public static string dogechain;

		// Token: 0x04000021 RID: 33
		public static string tron;

		// Token: 0x04000022 RID: 34
		public static string payeer;

		// Token: 0x04000023 RID: 35
		public static string yd;

		// Token: 0x04000024 RID: 36
		public static string qiwi;
	}
}
