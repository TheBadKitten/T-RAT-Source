﻿using System;

namespace TelegramBot
{
	// Token: 0x0200000E RID: 14
	public static class Enums
	{
		// Token: 0x0200000F RID: 15
		public enum ClipboardFormat : byte
		{
			// Token: 0x04000016 RID: 22
			Text,
			// Token: 0x04000017 RID: 23
			UnicodeText
		}
	}
}
